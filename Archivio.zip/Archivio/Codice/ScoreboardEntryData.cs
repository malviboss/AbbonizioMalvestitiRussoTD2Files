﻿using System;

namespace Fabio.Scoreboards
{
    [Serializable]
    public struct ScoreboardEntryData 
    {
        public string entryName;
        public int entryScore;
    }
}

