﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Selected : MonoBehaviour
{
    public bool isActive, isDead;
    public bool isAlone = false;

    
}